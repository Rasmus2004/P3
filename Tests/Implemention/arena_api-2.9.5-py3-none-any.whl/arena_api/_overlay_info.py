# -----------------------------------------------------------------------------
# Copyright (c) 2026, Lucid Vision Labs, Inc.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
# OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS
# BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
# ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
# THE SOFTWARE.
# -----------------------------------------------------------------------------

from arena_api import enums as _enums
from arena_api._node_helpers import \
    cast_from_general_node_to_specific_node_type as \
    _cast_from_general_node_to_specific_node_type
from arena_api._xlayer.xarena._xbuffer import _xBuffer
from arena_api._xlayer.xarena._ximagefactory import _xImagefactory
from arena_api._xlayer.xarena._xoverlayinfo import _xOverlayInfo
from arena_api._node import Node as _Node

import ctypes

class OverlayInfo():
    
    def __init__(self, hxoverlay_info):
        self._xoverlay_info = _xOverlayInfo(hxoverlay_info)
    
    # ---------------------------------------------------------------------

    def get_scale(self):
        return self._xoverlay_info.xGetScale(self)

    def get_coordinate_offset_a(self):
        return self._xoverlay_info.xGetCoordinateOffsetA(self)
    
    def get_coordinate_offset_b(self):
        return self._xoverlay_info.xGetCoordinateOffsetB(self)
    
    def get_coordinate_offset_c(self):
        return self._xoverlay_info.xGetCoordinateOffsetC(self)
