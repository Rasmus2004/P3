# -----------------------------------------------------------------------------
# Copyright (c) 2024, Lucid Vision Labs, Inc.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
# OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS
# BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
# ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
# THE SOFTWARE.
# -----------------------------------------------------------------------------

from ctypes import POINTER, byref, c_void_p, c_size_t, c_uint8, c_bool

from arena_api._xlayer.xarena.arenac import harenac
from arena_api._xlayer.xarena.arenac_types import (
    acODevFileStream,
    acIDevFileStream,
    acNodeMap,
    uint32_t,
    bool8_t,
    uint8_t,
    char_ptr,
)

class _xODevFileStream:

    def __init__(self, ac_nodemap, file_name):
        self.ac_Odevfilestream = self._xODevFileStreamOpen(
            ac_nodemap, file_name)
        print("File stream opened successfully")

    def __del__(self):
        self._xODevFileStreamClose()

    def _xODevFileStreamClose(self):
        # AC_ERROR acODevFileStreamClose(
        #   acODevFileStream hStream)
        harenac.acODevFileStreamClose(
            self.ac_Odevfilestream)

    def _xODevFileStreamOpen(self,ac_nodemap,file_name,open_mode = 0):
        file_name_p = char_ptr(file_name.encode())
        ac_Odevfilestream = acODevFileStream(None)
        h_nodemap = acNodeMap(ac_nodemap._Nodemap__xnodemap.h_nodemap.value)
        open_mode = uint32_t(open_mode)
        # AC_ERROR acODevFileStreamOpen(
        #   acODevFileStream* phODevFileStream,
        #   acNodeMap hNodeMap,
        #   const char* pFileName,
        #   AC_O_DEV_FILE_STREAM_OPEN_MODE openMode)
        harenac.acODevFileStreamOpen(
            byref(ac_Odevfilestream),
            h_nodemap,
            file_name_p,
            open_mode
        )
        return ac_Odevfilestream

    def _acODevFileStreamWrite(self, pdata, data_len):
        # AC_ERROR acODevFileStreamWrite(
        #   acODevFileStream hODevFileStream,
        #   const char* pBuf,
        #   size_t bufLen)
        print(type(pdata))
        harenac.acODevFileStreamWrite(
            self.ac_Odevfilestream,
            byref(pdata),
            data_len
        )

    def _acODevFileStreamFail(self):
        is_fail = bool8_t(False)
        # AC_ERROR acODevFileStreamFail(
        #   acODevFileStream hODevFileStream,
        #   bool8_t* pFail)
        harenac.acODevFileStreamFail(
            self.ac_Odevfilestream,
            byref(is_fail)
        )
        return bool(is_fail.value)

class _xIDevFileStream:
    def __init__(self, ac_nodemap,file_name):
        self.ac_Idevfilestream_address = self._xIDevFileStreamOpen(
            ac_nodemap, file_name)
        self.ac_Idevfilestream = acIDevFileStream(self.ac_Idevfilestream_address)

    def __del__(self):
        self._xIDevFileStreamClose()

    def _xIDevFileStreamClose(self):
        # AC_ERROR acIDevFileStreamClose(
        #   acIDevFileStream hStream)
        harenac.acIDevFileStreamClose(
            self.ac_featurestream)

    def _xIDevFileStreamOpen(self,ac_nodemap,file_name):
        file_name_p = char_ptr(file_name.encode())
        ac_Idevfilestream = acIDevFileStream(None)
        # AC_ERROR acIDevFileStreamOpen(
        #   acIDevFileStream* phIDevFileStream,
        #   acNodeMap hNodeMap,
        #   const char* pFileName)
        harenac.acIDevFileStreamOpen(
            byref(ac_Idevfilestream),
            ac_nodemap,
            file_name_p
        )

    def _acIDevFileStreamRead(self, data_len):
        pdata = (c_uint8 * data_len)
        # AC_ERROR acIDevFileStreamRead(
        #   acIDevFileStream hIDevFileStream,
        #   const void* pBuf,
        #   size_t bufLen)
        harenac.acIDevFileStreamRead(
            self.ac_Idevfilestream,
            byref(pdata),
            data_len
        )
        return pdata

    def _acIDevFileStreamFail(self):
        is_fail = bool8_t(False)
        # AC_ERROR acIDevFileStreamFail(
        #   acIDevFileStream hIDevFileStream,
        #   bool8_t* pFail)
        harenac.acIDevFileStreamFail(
            self.ac_Idevfilestream,
            byref(is_fail)
        )
        return bool(is_fail.value)