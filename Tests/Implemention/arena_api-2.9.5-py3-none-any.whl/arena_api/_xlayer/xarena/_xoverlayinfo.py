# -----------------------------------------------------------------------------
# Copyright (c) 2026, Lucid Vision Labs, Inc.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
# OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS
# BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
# ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
# THE SOFTWARE.
# -----------------------------------------------------------------------------

from ctypes import byref

from arena_api._xlayer.xarena.arenac import harenac
from arena_api._xlayer.xarena.arenac_types import (ac_bayer_algorithm,
                                                   acBuffer, size_t, uint64_t, 
                                                   double, acOverlayInfo, acDevice)


class _xOverlayInfo():

    def __init__(self, hxoverlay_info):
        if not hxoverlay_info:
            raise TypeError('xOverlayInfo handle is None')
        self.hxoverlay_info = acOverlayInfo(hxoverlay_info)

    @staticmethod
    def xGetScale(self):

        scale = double(0)
        # AC_ERROR AC_API acOverlayInfoGetScale(
        # acOverlayInfo hOverlayInfo,
        # double* pScale) 
        harenac.acOverlayInfoGetScale(
            acOverlayInfo(self._xoverlay_info.hxoverlay_info.value),
            byref(scale))

        return scale.value
    
    @staticmethod
    def xGetCoordinateOffsetA(self):

        offset_a = double(0)
        # AC_ERROR AC_API acOverlayInfoGetCoordinateOffsetA(
        # acOverlayInfo hOverlayInfo,
        # double* pCoordinateOffsetA)
        harenac.acOverlayInfoGetCoordinateOffsetA(
            acOverlayInfo(self._xoverlay_info.hxoverlay_info.value),
            byref(offset_a))

        return offset_a.value
    
    @staticmethod
    def xGetCoordinateOffsetB(self):

        offset_b = double(0)
        # AC_ERROR AC_API acOverlayInfoGetCoordinateOffsetB(
        # acOverlayInfo hOverlayInfo,
        # double* pCoordinateOffsetB)
        harenac.acOverlayInfoGetCoordinateOffsetB(
            acOverlayInfo(self._xoverlay_info.hxoverlay_info.value),
            byref(offset_b))

        return offset_b.value
    
    @staticmethod
    def xGetCoordinateOffsetC(self):

        offset_c = double(0)
        # AC_ERROR AC_API acOverlayInfoGetCoordinateOffsetC(
        # acOverlayInfo hOverlayInfo,
        # double* pCoordinateOffsetC)
        harenac.acOverlayInfoGetCoordinateOffsetC(
            acOverlayInfo(self._xoverlay_info.hxoverlay_info.value),
            byref(offset_c))

        return offset_c.value